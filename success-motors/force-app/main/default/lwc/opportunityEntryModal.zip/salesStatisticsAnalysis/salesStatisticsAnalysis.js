import { LightningElement, api, wire, track } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';

import getAccountById from '@salesforce/apex/AccountContoller.getAccountById';
import getAccounts from '@salesforce/apex/AccountContoller.getAccounts';


export default class SalesStatisticsAnalysis extends LightningElement {
    @api recordId;
    @wire(CurrentPageReference) currentPageReference;
    @track account;
    @track allAccount;

    get isAccountDetailPage() {
        return (
            this.currentPageReference &&
            this.currentPageReference.type === 'standard__recordPage' &&
            this.currentPageReference.attributes.objectApiName === 'Account' &&
            this.currentPageReference.attributes.recordId === this.recordId
        );
    }

    @wire(getAccountById, { accountId: '$recordId' })
    wiredGetAccountById({error, data}){
        if(data){
            this.account = data;
            console.log("Update 7.0");
            console.log("Data about account ", data);
        }
        else if(error){
            console.log('Something went wrong while receive account: ', error);
        }
    }

    connectedCallback() {
        this.retrieveAccounts();
    }

    retrieveAccounts() {
        getAccounts()
            .then(result => {
                this.allAccount = result;
                console.log("all accounts loaded", result);
            })
            .catch(error => {
                console.log('all accounts:', error);
            });
    }



    // @wire(getAccountCloseWonSum, { accountId: '$recordId' })
    // wiredCloseWonSum({ data, error }) {
    //     if (data) {
    //         this.closeWonSum = data['totalAmount'];
    //         if(this.closeWonSum===undefined)
    //             this.closeWonSum ='0.00';
    //         console.log("Data about total Amount ", data);
    //     } else if (error) {
    //         console.log('Something went wrong while receive total Amount: ', error);
    //     }
    // }

    // @wire(getOpportunityByAccountId, { accountId: '$recordId' })
    // wiredGetOpportunityByAccountId({error, data}){
    //     if(data){
    //         this.opportunityList = data;
    //         console.log("Data about opportunity ", data);
        
    //     }
    //     else if(error){
    //         console.log('Something went wrong while receive opportunity: ', error);
    //     }
    // }
}